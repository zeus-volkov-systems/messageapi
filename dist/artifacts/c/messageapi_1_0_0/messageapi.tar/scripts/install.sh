#!/bin/bash

echo "Installing the full MessageAPI C library for user $(whoami)."

echo "Finished installing the MessageAPI C session library."